#include <stdio.h>

#include "test/NodeTest.h"

int main(){
    runNodeTests();

    return 0;
}
